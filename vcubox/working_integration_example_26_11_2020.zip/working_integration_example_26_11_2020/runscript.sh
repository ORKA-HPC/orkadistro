#!/usr/bin/env bash
sudo LD_LIBRARY_PATH="$PWD" ./hostBinary
